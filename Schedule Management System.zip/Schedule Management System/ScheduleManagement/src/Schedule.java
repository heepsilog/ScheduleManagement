public class Schedule {
    private int id;
    private String subject;
    private String room;
    private String section;  // ➡️ Added section
    private String day;
    private String startTime;
    private String endTime;

    // Constructor
    public Schedule(int id, String subject, String room, String section, String day, String startTime, String endTime) {
        this.id = id;
        this.subject = subject;
        this.room = room;
        this.section = section;  // ➡️ Include section
        this.day = day;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getRoom() { return room; }
    public void setRoom(String room) { this.room = room; }

    public String getSection() { return section; }  // ➡️ Section getter
    public void setSection(String section) { this.section = section; }  // ➡️ Section setter

    public String getDay() { return day; }
    public void setDay(String day) { this.day = day; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }
}
