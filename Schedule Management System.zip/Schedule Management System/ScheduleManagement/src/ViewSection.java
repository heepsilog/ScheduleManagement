import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class ViewSection extends javax.swing.JFrame {

    private JFrame previousFrame;
    private JComboBox<String> sectionSelector;
    private JTable scheduleTable;
    private JPanel leftPanel;
    private JPanel rightPanel;

    public ViewSection(JFrame previousFrame) {
        this.previousFrame = previousFrame;
        initComponents();
        loadSections();

        sectionSelector.addActionListener(e -> {
            String selectedSection = (String) sectionSelector.getSelectedItem();
            if (selectedSection != null) {
                loadScheduleForSection(selectedSection);
            }
        });
    }

    private void loadSections() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT class_section_name FROM class_sections";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            Vector<String> sections = new Vector<>();
            while (rs.next()) {
                sections.add(rs.getString("class_section_name"));
            }

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(sections);
            sectionSelector.setModel(model);

            if (!sections.isEmpty()) {
                loadScheduleForSection(sections.get(0));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading sections: " + e.getMessage());
        }
    }

    private void loadScheduleForSection(String sectionName) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = """
                SELECT s.day_of_week, s.start_time, s.end_time, sub.subject_name, r.room_name, i.instructor_name
                FROM schedules s
                JOIN subjects sub ON s.subject_id = sub.subject_id
                JOIN rooms r ON s.room_id = r.room_id
                JOIN instructors i ON s.instructor_id = i.instructor_id
                JOIN class_sections sec ON s.class_section_id = sec.class_section_id
                WHERE sec.class_section_name = ?
                ORDER BY s.day_of_week, s.start_time
                """;

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, sectionName);
            ResultSet rs = stmt.executeQuery();

            DefaultTableModel model = (DefaultTableModel) scheduleTable.getModel();
            model.setRowCount(0); // Clear previous data

            while (rs.next()) {
                String day = rs.getString("day_of_week");
                String startTime = rs.getString("start_time");
                String endTime = rs.getString("end_time");
                String subject = rs.getString("subject_name");
                String room = rs.getString("room_name");
                String instructor = rs.getString("instructor_name");

                String timeSlot = startTime + " - " + endTime;
                model.addRow(new Object[]{timeSlot, day, subject, room, instructor, startTime, endTime});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading schedule: " + e.getMessage());
        }
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Section Schedules");

        // Full-screen
        setSize(1920, 1000);
        setLocationRelativeTo(null);

        // Left panel
        leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(300, getHeight()));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Select Section:");
        sectionSelector = new JComboBox<>();
        sectionSelector.setPreferredSize(new Dimension(250, 30));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout(10, 10));
        topPanel.add(label, BorderLayout.NORTH);
        topPanel.add(sectionSelector, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.setPreferredSize(new Dimension(100, 30));
        backButton.addActionListener(e -> {
            previousFrame.setVisible(true);
            this.dispose();
        });

        leftPanel.add(topPanel, BorderLayout.NORTH);
        leftPanel.add(backButton, BorderLayout.SOUTH);

        // Right panel with table
        rightPanel = new JPanel(new BorderLayout());
        scheduleTable = new JTable(new DefaultTableModel(
                new Object[]{"Time Slot", "Day", "Subject", "Room", "Instructor", "Start Time", "End Time"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });

        scheduleTable.setRowHeight(30);
        JTableHeader header = scheduleTable.getTableHeader();
        header.setFont(header.getFont().deriveFont(Font.BOLD, 14f));
        scheduleTable.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(scheduleTable);
        rightPanel.add(scrollPane, BorderLayout.CENTER);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(leftPanel, BorderLayout.WEST);
        getContentPane().add(rightPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame dummy = new JFrame("UserDashboard");
            dummy.setSize(400, 300);
            dummy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            dummy.setVisible(true);

            ViewSection viewSection = new ViewSection(dummy);
            viewSection.setVisible(true);
            dummy.setVisible(false);
        });
    }
}

