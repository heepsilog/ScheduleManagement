/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

/**
 *
 * @author Jayvie
 */
public class ViewList extends javax.swing.JFrame {

    private JFrame previousFrame;
    private JComboBox<String> instructorSelector;
    private JTable scheduleTable;
    private JPanel leftPanel;
    private JPanel rightPanel;

    /**
     * Creates new form ViewList
     */
    public ViewList(JFrame previousFrame) {
        this.previousFrame = previousFrame;
        initComponents();
        loadInstructors();

        instructorSelector.addActionListener(e -> {
            String selectedInstructor = (String) instructorSelector.getSelectedItem();
            if (selectedInstructor != null) {
                loadScheduleForInstructor(selectedInstructor);
            }
        });
    }

    private void loadInstructors() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT instructor_name FROM instructors";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            Vector<String> instructors = new Vector<>();
            while (rs.next()) {
                instructors.add(rs.getString("instructor_name"));
            }

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(instructors);
            instructorSelector.setModel(model);

            if (!instructors.isEmpty()) {
                loadScheduleForInstructor(instructors.get(0));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading instructors: " + e.getMessage());
        }
    }

   private void loadScheduleForInstructor(String instructorName) {
    try (Connection conn = DatabaseConnection.getConnection()) {
       String sql = """
    SELECT s.day_of_week, s.start_time, s.end_time, sub.subject_name, r.room_name, sec.class_section_name
    FROM schedules s
    JOIN subjects sub ON s.subject_id = sub.subject_id
    JOIN rooms r ON s.room_id = r.room_id
    JOIN instructors i ON s.instructor_id = i.instructor_id
    JOIN class_sections sec ON s.class_section_id = sec.class_section_id
    WHERE i.instructor_name = ?
    ORDER BY s.day_of_week, s.start_time
    """;




        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, instructorName);
        ResultSet rs = stmt.executeQuery();

        DefaultTableModel model = (DefaultTableModel) scheduleTable.getModel();
        model.setRowCount(0); // Clear previous data

        while (rs.next()) {
            String day = rs.getString("day_of_week");
            String startTime = rs.getString("start_time");
            String endTime = rs.getString("end_time");
            String subject = rs.getString("subject_name");
            String room = rs.getString("room_name");
            String section = rs.getString("class_section_name");

            String timeSlot = startTime + " - " + endTime;
            model.addRow(new Object[]{timeSlot, day, subject, room, section, startTime, endTime});
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error loading schedule: " + e.getMessage());
    }
}


    /**
     * Initializes the form
     */
    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Instructor Schedules");

        // Force full screen size
        setSize(1920, 1000);
        setLocationRelativeTo(null); // Center on screen

        // Main panels
        leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(300, getHeight()));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Select Instructor:");
        instructorSelector = new JComboBox<>();
        instructorSelector.setPreferredSize(new Dimension(250, 30));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout(10, 10));
        topPanel.add(label, BorderLayout.NORTH);
        topPanel.add(instructorSelector, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.setPreferredSize(new Dimension(100, 30));
        backButton.addActionListener(e -> {
            previousFrame.setVisible(true);
            this.dispose();
        });

        leftPanel.add(topPanel, BorderLayout.NORTH);
        leftPanel.add(backButton, BorderLayout.SOUTH);

        // Right panel with table
        rightPanel = new JPanel(new BorderLayout());
        scheduleTable = new JTable(new DefaultTableModel(
                new Object[]{"Time Slot", "Day", "Subject", "Room", "Section", "Start Time", "End Time"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });

        scheduleTable.setRowHeight(30);
        JTableHeader header = scheduleTable.getTableHeader();
        header.setFont(header.getFont().deriveFont(Font.BOLD, 14f));
        scheduleTable.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(scheduleTable);
        rightPanel.add(scrollPane, BorderLayout.CENTER);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(leftPanel, BorderLayout.WEST);
        getContentPane().add(rightPanel, BorderLayout.CENTER);
    }

    /**
     * Main method to run
     */
    public static void main(String[] args) {
        // Example to run with a dummy UserDashboard frame
        SwingUtilities.invokeLater(() -> {
            JFrame dummy = new JFrame("UserDashboard");
            dummy.setSize(400, 300);
            dummy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            dummy.setVisible(true);

            ViewList viewList = new ViewList(dummy);
            viewList.setVisible(true);
            dummy.setVisible(false);
        });
    }
}
